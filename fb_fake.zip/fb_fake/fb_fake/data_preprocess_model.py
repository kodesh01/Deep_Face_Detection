from dataset_load import fb_df_train,fb_df_test
from import_libs import *
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

# Prepare Data to Train the Model

# Training and testing dataset (inputs)
X_train = fb_df_train.drop(columns=['fake'])
X_test = fb_df_test.drop(columns=['fake'])

print("X_train:", X_train.head())
print("X_test:", X_test.head())

# Training and testing dataset (outputs)
y_train = fb_df_train['fake']
y_test = fb_df_test['fake']

print("y_train:", y_train.head())
print("y_test:", y_test.head())

# Scale the data before training the model
scaler_x = StandardScaler()
X_train = scaler_x.fit_transform(X_train)
X_test = scaler_x.transform(X_test)

# Convert labels to categorical (one-hot encoding)
y_train = tf.keras.utils.to_categorical(y_train, num_classes=2)
y_test = tf.keras.utils.to_categorical(y_test, num_classes=2)

print("y_train after encoding:", y_train[:5])
print("y_test after encoding:", y_test[:5])

# Print the shapes of training and testing datasets
print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

# Calculate and print percentages
Training_data = len(X_train) / (len(X_test) + len(X_train)) * 100
Testing_data = len(X_test) / (len(X_test) + len(X_train)) * 100

print("Training data percentage:", Training_data)
print("Testing data percentage:", Testing_data)
