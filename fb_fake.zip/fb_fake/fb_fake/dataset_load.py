from import_libs import *

train_data_path = 'datasets/Fake-fb-Profile-Detection-main/fb_train.csv'
test_data_path = 'datasets/Fake-fb-Profile-Detection-main/fb_test.csv'

pd.read_csv(test_data_path)


train_data_path = 'datasets/fb_Fake_Profile_Detection/train.csv'
test_data_path = 'datasets/fb_Fake_Profile_Detection/test.csv'

pd.read_csv(train_data_path)

# Load the training dataset
fb_df_train=pd.read_csv(train_data_path)
fb_df_train

# Load the testing data
fb_df_test=pd.read_csv(test_data_path)
fb_df_test