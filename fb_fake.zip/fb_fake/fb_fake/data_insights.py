from dataset_load import fb_df_train,fb_df_test
from import_libs import *
fb_df_train.head()
fb_df_train.tail()

fb_df_test.head()
fb_df_test.tail()

# Getting dataframe info
fb_df_train.info()

# Get the statistical summary of the dataframe
fb_df_train.describe()

# Checking if null values exist
fb_df_train.isnull().sum()



# Get the number of unique values in the "profile pic" feature
fb_df_train['profile pic'].value_counts()

# Get the number of unique values in "fake" (Target column)
fb_df_train['fake'].value_counts()

fb_df_test.info()

fb_df_test.describe()

fb_df_test.isnull().sum()

fb_df_test['fake'].value_counts()

# Perform Data Visualizations

# Visualize the data
sns.countplot(fb_df_train['fake'])
plt.show()

# Visualize the private column data
sns.countplot(fb_df_train['private'])
plt.show()

# Visualize the "profile pic" column data
sns.countplot(sns.countplot(fb_df_train['profile pic'])
['profile pic'])
plt.show()

# Visualize the data
plt.figure(figsize = (20, 10))
sns.distplot(fb_df_train['nums/length username'])
plt.show()

# Correlation plot
plt.figure(figsize=(20, 20))
cm = fb_df_train.corr()
ax = plt.subplot()
sns.heatmap(cm, annot = True, ax = ax)
plt.show()

sns.countplot(fb_df_train['fake'])

sns.countplot(fb_df_train['private'])

sns.countplot(fb_df_train['profile pic'])